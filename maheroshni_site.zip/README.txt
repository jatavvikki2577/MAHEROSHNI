Maheroshni Micro Service Foundation — Website package
Files included:
- index.html
- about.html
- services.html
- team.html
- contact.html
- assets/style.css
- assets/script.js

Notes:
- Contact form on contact.html is configured for Netlify forms (data-netlify="true"). To receive submissions:
  1) Deploy the site on Netlify (drag & drop or connect a Git repo).
  2) Netlify will capture form submissions and you can enable email notifications or webhook forwarding.

Hosting suggestions:
- Netlify (recommended for easy form handling and free SSL)
- GitHub Pages (static-only; forms won't work automatically)
- Vercel

CIN included in site: U88900UP2024NPL208817
Primary email used: mrmsfoundation1@gmail.com

If you want:
- I can deploy it to Netlify for you (you need to connect your GitHub account or allow drag-and-drop).
- Or I can convert forms to use Formspree / EmailJS if you prefer an email delivery service.
