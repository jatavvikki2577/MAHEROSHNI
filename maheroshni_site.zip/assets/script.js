
// Small UI helpers
document.addEventListener('DOMContentLoaded', function(){
  // nothing yet - placeholder for future interactions
  console.log('Maheroshni site loaded');
});
